## 📊 Reports

### 🏢 Property Availability Report

![Property Availability](./images/property-availability-report.png)

> Track real-time property inventory with occupancy status, unit specifications (bedrooms, bathrooms, size), and total asset value across your portfolio. Visualize vacancy rates and property distribution.

### 🛠️ Service Request Summary

![Service Requests](./images/service-request-report.png)

> Monitor the complete lifecycle of service requests from initiation to billing. Analyze request types, completion statuses, and associated billing progress across different customer segments.

### 📝 Tenancy Summary Report

![Tenancy](./images/tenancy-report.png)

> Manage lease contracts with visibility on active/expired agreements, remaining lease durations, and property assignments. Track contract adjustments and insurance coverage status.

### 🔌 Meter Reading Summary

![Meter Readings](./images/meter-reading-report.png)

> Analyze utility consumption patterns with detailed meter reading comparisons. View consumption by item type, tariff block rates, and generated billing amounts for accurate utility cost tracking.

## 🚀 Quick Navigation

[![Home](https://img.shields.io/badge/Home-DEF4FF?style=for-the-badge&logo=github&logoColor=000)](https://github.com/navariltd/utility-billing)
[![Full Documentation](https://img.shields.io/badge/Full_Documentation-6366F1?style=for-the-badge&logo=readthedocs&logoColor=fff)](https://github.com/navariltd/utility-billing/wiki)
[![ERPNext Docs](https://img.shields.io/badge/ERPNext_Docs-FF6B6B?style=for-the-badge&logo=erpnext&logoColor=fff)](https://docs.erpnext.com)
[![Frappe Framework](https://img.shields.io/badge/Frappe_Framework-00C49A?style=for-the-badge&logo=frappe&logoColor=fff)](https://frappeframework.com/docs)
[![Community Forum](https://img.shields.io/badge/Community_Forum-F59E0B?style=for-the-badge&logo=discourse&logoColor=fff)](https://discuss.frappe.io)
[![Report Issue](https://img.shields.io/badge/Report_Issue-E63946?style=for-the-badge&logo=githubissues&logoColor=fff)](https://github.com/navariltd/utility-billing/issues)
[![Website](https://img.shields.io/badge/Website-1E293B?style=for-the-badge&logo=googlechrome&logoColor=fff)](https://navari.co.ke)
