# 🧾 **Sales Order and Invoice Customizations**

The **Sales Order** and **Sales Invoice** Doctypes in ERPNext have been customized to incorporate new fields and sections related to utility billing, meter readings, and service requests. These customizations streamline the integration of utility information directly into the sales workflow, making it easier to track, manage, and bill utility services along with regular sales processes.

![Sales Order Overview](https://raw.githubusercontent.com/navariltd/utility-billing/refs/heads/develop/utility_billing/docs/images/sales-order.png)
![Sales Invoice Overview](https://raw.githubusercontent.com/navariltd/utility-billing/refs/heads/develop/utility_billing/docs/images/sales-invoice.png)

## Key Features

- **Meter Readings**: Capture and manage utility meter readings within both the sales order and invoice.
- **Utility Service Request Link**: Link both sales orders and invoices to specific utility service requests for better tracking and management.
- **Block Information**: Attach utility tariff block information to items in both sales orders and invoices, ensuring accurate billing.

---

## Custom Fields and Functionality

### 1. **Meter Readings Table**

The **Meter Readings** table allows utility meter readings to be captured for both sales orders and invoices. This ensures that all utility-related data is available for accurate billing.

### 2. **Utility Service Request Link**

This field links the sales order and sales invoice to a **Utility Service Request**, making it easy to track the specific utility services associated with each order or invoice.

### 3. **Block Information for Items**

A **Link** field is added to both the sales order and sales invoice item sections, allowing each item to be associated with a **Utility Tariff Block** for accurate utility billing.

---

## 🚀 Quick Navigation

[![Home](https://img.shields.io/badge/Home-DEF4FF?style=for-the-badge&logo=github&logoColor=000)](https://github.com/navariltd/utility-billing)
[![Full Documentation](https://img.shields.io/badge/Full_Documentation-6366F1?style=for-the-badge&logo=readthedocs&logoColor=fff)](https://github.com/navariltd/utility-billing/wiki)
[![ERPNext Docs](https://img.shields.io/badge/ERPNext_Docs-FF6B6B?style=for-the-badge&logo=erpnext&logoColor=fff)](https://docs.erpnext.com)
[![Frappe Framework](https://img.shields.io/badge/Frappe_Framework-00C49A?style=for-the-badge&logo=frappe&logoColor=fff)](https://frappeframework.com/docs)
[![Community Forum](https://img.shields.io/badge/Community_Forum-F59E0B?style=for-the-badge&logo=discourse&logoColor=fff)](https://discuss.frappe.io)
[![Report Issue](https://img.shields.io/badge/Report_Issue-E63946?style=for-the-badge&logo=githubissues&logoColor=fff)](https://github.com/navariltd/utility-billing/issues)
[![Website](https://img.shields.io/badge/Website-1E293B?style=for-the-badge&logo=googlechrome&logoColor=fff)](https://navari.co.ke)
