// Copyright (c) 2024, Navari and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Utility Request Type", {
// 	refresh(frm) {

// 	},
// });
