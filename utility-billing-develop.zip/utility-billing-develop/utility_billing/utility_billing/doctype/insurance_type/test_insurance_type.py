# Copyright (c) 2025, Navari Ltd and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestInsuranceType(FrappeTestCase):
	pass
