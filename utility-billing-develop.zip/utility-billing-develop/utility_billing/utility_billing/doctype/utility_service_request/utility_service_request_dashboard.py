def get_data():
    return {
        "fieldname": "utility_service_request",
        "transactions": [
            {
                "label": "Sales",
                "items": [
                    "Sales Order",
                    "Sales Invoice",
                ],
            },
            {
                "label": "Project",
                "items": [
                    "Issue",
                ],
            },
            {
                "label": "Material",
                "items": [
                    "BOM",
                ],
            },
            {
                "label": "Contract Management",
                "items": [
                    "Contract",
                ],
            },
        ],
    }
