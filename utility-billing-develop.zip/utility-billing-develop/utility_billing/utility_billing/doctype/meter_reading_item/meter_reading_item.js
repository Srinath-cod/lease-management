// Copyright (c) 2024, Navari and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Meter Reading Item", {
// 	refresh(frm) {

// 	},
// });
