// Copyright (c) 2025, Navari and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Utility Property Feature Type", {
// 	refresh(frm) {

// 	},
// });
